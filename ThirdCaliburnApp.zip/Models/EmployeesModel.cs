﻿namespace ThirdCaliburnApp.Models
{
    public class EmployeesModel
    {
        public int id { get; set; }
        public string EmpName { get; set; }
        public decimal Salary { get; set; }
        public string DeptName { get; set; }
        public string Destination { get; set; }
    }
}
